import mysql.connector
from mysql.connector import Error
from config import DB_CONFIG


def get_connection():
    """Create and return a MySQL connection."""
    return mysql.connector.connect(**DB_CONFIG)


def test_connection():
    """Return True if the database connection works."""
    connection = None
    try:
        connection = get_connection()
        return connection.is_connected()
    except Error:
        return False
    finally:
        if connection and connection.is_connected():
            connection.close()
