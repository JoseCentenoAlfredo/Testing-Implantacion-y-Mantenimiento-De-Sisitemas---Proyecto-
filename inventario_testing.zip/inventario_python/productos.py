from mysql.connector import Error
from db import get_connection


class ProductoService:
    @staticmethod
    def listar_productos(filtro: str = ""):
        connection = None
        cursor = None
        try:
            connection = get_connection()
            cursor = connection.cursor(dictionary=True)
            if filtro.strip():
                sql = """
                    SELECT p.id_producto, p.codigo, p.nombre, p.descripcion,
                           c.nombre AS categoria, p.unidad_medida,
                           p.precio_compra, p.precio_venta,
                           p.stock_actual, p.stock_minimo, p.estado
                    FROM productos p
                    INNER JOIN categorias c ON p.id_categoria = c.id_categoria
                    WHERE p.codigo LIKE %s OR p.nombre LIKE %s OR c.nombre LIKE %s
                    ORDER BY p.id_producto DESC
                """
                like = f"%{filtro}%"
                cursor.execute(sql, (like, like, like))
            else:
                sql = """
                    SELECT p.id_producto, p.codigo, p.nombre, p.descripcion,
                           c.nombre AS categoria, p.unidad_medida,
                           p.precio_compra, p.precio_venta,
                           p.stock_actual, p.stock_minimo, p.estado
                    FROM productos p
                    INNER JOIN categorias c ON p.id_categoria = c.id_categoria
                    ORDER BY p.id_producto DESC
                """
                cursor.execute(sql)
            return cursor.fetchall()
        except Error as exc:
            raise RuntimeError(f"Error al listar productos: {exc}") from exc
        finally:
            if cursor:
                cursor.close()
            if connection and connection.is_connected():
                connection.close()

    @staticmethod
    def listar_categorias():
        connection = None
        cursor = None
        try:
            connection = get_connection()
            cursor = connection.cursor(dictionary=True)
            cursor.execute(
                "SELECT id_categoria, nombre FROM categorias WHERE estado = 1 ORDER BY nombre"
            )
            return cursor.fetchall()
        except Error as exc:
            raise RuntimeError(f"Error al listar categorías: {exc}") from exc
        finally:
            if cursor:
                cursor.close()
            if connection and connection.is_connected():
                connection.close()

    @staticmethod
    def existe_codigo(codigo: str, excluir_id: int | None = None):
        connection = None
        cursor = None
        try:
            connection = get_connection()
            cursor = connection.cursor()
            if excluir_id is None:
                cursor.execute("SELECT COUNT(*) FROM productos WHERE codigo = %s", (codigo,))
            else:
                cursor.execute(
                    "SELECT COUNT(*) FROM productos WHERE codigo = %s AND id_producto <> %s",
                    (codigo, excluir_id),
                )
            total = cursor.fetchone()[0]
            return total > 0
        except Error as exc:
            raise RuntimeError(f"Error al validar código de producto: {exc}") from exc
        finally:
            if cursor:
                cursor.close()
            if connection and connection.is_connected():
                connection.close()

    @staticmethod
    def registrar_producto(data: dict):
        connection = None
        cursor = None
        try:
            connection = get_connection()
            cursor = connection.cursor()
            sql = """
                INSERT INTO productos (
                    codigo, nombre, descripcion, id_categoria,
                    unidad_medida, precio_compra, precio_venta,
                    stock_actual, stock_minimo, estado
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            values = (
                data["codigo"],
                data["nombre"],
                data.get("descripcion", ""),
                data["id_categoria"],
                data.get("unidad_medida", "unidad"),
                data.get("precio_compra", 0),
                data.get("precio_venta", 0),
                data.get("stock_actual", 0),
                data.get("stock_minimo", 0),
                data.get("estado", 1),
            )
            cursor.execute(sql, values)
            connection.commit()
        except Error as exc:
            if connection:
                connection.rollback()
            raise RuntimeError(f"Error al registrar producto: {exc}") from exc
        finally:
            if cursor:
                cursor.close()
            if connection and connection.is_connected():
                connection.close()

    @staticmethod
    def actualizar_producto(id_producto: int, data: dict):
        connection = None
        cursor = None
        try:
            connection = get_connection()
            cursor = connection.cursor()
            sql = """
                UPDATE productos
                SET codigo = %s,
                    nombre = %s,
                    descripcion = %s,
                    id_categoria = %s,
                    unidad_medida = %s,
                    precio_compra = %s,
                    precio_venta = %s,
                    stock_actual = %s,
                    stock_minimo = %s,
                    estado = %s
                WHERE id_producto = %s
            """
            values = (
                data["codigo"],
                data["nombre"],
                data.get("descripcion", ""),
                data["id_categoria"],
                data.get("unidad_medida", "unidad"),
                data.get("precio_compra", 0),
                data.get("precio_venta", 0),
                data.get("stock_actual", 0),
                data.get("stock_minimo", 0),
                data.get("estado", 1),
                id_producto,
            )
            cursor.execute(sql, values)
            connection.commit()
        except Error as exc:
            if connection:
                connection.rollback()
            raise RuntimeError(f"Error al actualizar producto: {exc}") from exc
        finally:
            if cursor:
                cursor.close()
            if connection and connection.is_connected():
                connection.close()

    @staticmethod
    def eliminar_producto(id_producto: int):
        connection = None
        cursor = None
        try:
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("DELETE FROM productos WHERE id_producto = %s", (id_producto,))
            connection.commit()
        except Error as exc:
            if connection:
                connection.rollback()
            raise RuntimeError(
                "Error al eliminar producto. Si tiene movimientos registrados, borra primero esos movimientos o usa eliminación lógica. "
                f"Detalle: {exc}"
            ) from exc
        finally:
            if cursor:
                cursor.close()
            if connection and connection.is_connected():
                connection.close()
