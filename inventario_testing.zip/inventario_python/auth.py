from mysql.connector import Error
from db import get_connection


class AuthService:
    @staticmethod
    def login(username: str, password: str):
        connection = None
        cursor = None
        try:
            connection = get_connection()
            cursor = connection.cursor(dictionary=True)
            sql = """
                SELECT id_usuario, nombres, apellidos, username, rol, estado
                FROM usuarios
                WHERE username = %s AND clave = %s AND estado = 1
                LIMIT 1
            """
            cursor.execute(sql, (username, password))
            return cursor.fetchone()
        except Error as exc:
            raise RuntimeError(f"Error al iniciar sesión: {exc}") from exc
        finally:
            if cursor:
                cursor.close()
            if connection and connection.is_connected():
                connection.close()
