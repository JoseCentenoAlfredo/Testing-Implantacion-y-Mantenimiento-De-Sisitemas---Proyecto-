import re
import tkinter as tk
from tkinter import ttk, messagebox

from auth import AuthService
from db import test_connection
from productos import ProductoService


class LoginWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Inventario - Login")
        self.root.geometry("380x240")
        self.root.resizable(False, False)

        container = ttk.Frame(root, padding=20)
        container.pack(fill="both", expand=True)

        ttk.Label(container, text="Sistema de Inventario", font=("Arial", 15, "bold")).pack(pady=(0, 15))

        ttk.Label(container, text="Usuario:").pack(anchor="w")
        self.entry_user = ttk.Entry(container)
        self.entry_user.pack(fill="x", pady=(0, 10))
        self.entry_user.insert(0, "admin")

        ttk.Label(container, text="Clave:").pack(anchor="w")
        self.entry_pass = ttk.Entry(container, show="*")
        self.entry_pass.pack(fill="x", pady=(0, 15))
        self.entry_pass.insert(0, "admin123")

        ttk.Button(container, text="Ingresar", command=self.login).pack(fill="x")

        self.entry_user.bind("<Return>", lambda event: self.login())
        self.entry_pass.bind("<Return>", lambda event: self.login())

    def login(self):
        username = self.entry_user.get().strip()
        password = self.entry_pass.get().strip()

        if not username or not password:
            messagebox.showwarning("Aviso", "Ingrese usuario y contraseña.")
            return

        try:
            user = AuthService.login(username, password)
            if not user:
                messagebox.showerror("Error", "Credenciales incorrectas.")
                return

            self.root.destroy()
            app_root = tk.Tk()
            InventoryWindow(app_root, user)
            app_root.mainloop()
        except Exception as exc:
            messagebox.showerror("Error", str(exc))


class InventoryWindow:
    CODIGO_REGEX = re.compile(r"^[A-Z]\d{3}$")

    def __init__(self, root, user):
        self.root = root
        self.user = user
        self.selected_id = None
        self.categorias = []

        self.root.title(f"Sistema de Inventario - {user['nombres']} {user['apellidos']}")
        self.root.geometry("1240x650")

        self.build_ui()
        self.cargar_categorias()
        self.cargar_productos()

    def build_ui(self):
        top = ttk.Frame(self.root, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="Módulo de Inventario", font=("Arial", 15, "bold")).pack(side="left")
        ttk.Label(top, text=f"Usuario: {self.user['username']} | Rol: {self.user['rol']}").pack(side="right")

        busqueda = ttk.Frame(self.root, padding=(10, 0))
        busqueda.pack(fill="x")

        ttk.Label(busqueda, text="Buscar:").pack(side="left")
        self.entry_buscar = ttk.Entry(busqueda, width=40)
        self.entry_buscar.pack(side="left", padx=5)
        ttk.Button(busqueda, text="Buscar", command=self.buscar).pack(side="left")
        ttk.Button(busqueda, text="Mostrar todo", command=self.cargar_productos).pack(side="left", padx=5)

        cuerpo = ttk.Frame(self.root, padding=10)
        cuerpo.pack(fill="both", expand=True)
        cuerpo.columnconfigure(0, weight=2)
        cuerpo.columnconfigure(1, weight=1)
        cuerpo.rowconfigure(0, weight=1)

        self.tree = ttk.Treeview(
            cuerpo,
            columns=(
                "id", "codigo", "nombre", "descripcion", "categoria", "unidad",
                "pcompra", "pventa", "stock", "smin", "estado"
            ),
            show="headings",
            height=18,
        )
        headings = {
            "id": "ID",
            "codigo": "Código",
            "nombre": "Nombre",
            "descripcion": "Descripción",
            "categoria": "Categoría",
            "unidad": "Unidad",
            "pcompra": "P. Compra",
            "pventa": "P. Venta",
            "stock": "Stock",
            "smin": "Stock Mín.",
            "estado": "Estado",
        }
        widths = {
            "id": 45, "codigo": 90, "nombre": 180, "descripcion": 0, "categoria": 110,
            "unidad": 80, "pcompra": 80, "pventa": 80, "stock": 70, "smin": 80, "estado": 70
        }

        for col in self.tree["columns"]:
            self.tree.heading(col, text=headings[col])
            if col == "descripcion":
                self.tree.column(col, width=0, stretch=False)
            else:
                self.tree.column(col, width=widths[col], anchor="center")

        self.tree.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.tree.bind("<<TreeviewSelect>>", self.seleccionar_producto)

        scrollbar = ttk.Scrollbar(cuerpo, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        scrollbar.grid(row=0, column=0, sticky="nse")

        form = ttk.LabelFrame(cuerpo, text="Datos del producto", padding=12)
        form.grid(row=0, column=1, sticky="nsew")

        labels = [
            "Código", "Nombre", "Descripción", "Categoría", "Unidad",
            "Precio compra", "Precio venta", "Stock actual", "Stock mínimo", "Estado"
        ]

        for i, text in enumerate(labels):
            ttk.Label(form, text=f"{text}:").grid(row=i, column=0, sticky="w", pady=4)

        self.var_codigo = tk.StringVar()
        self.var_nombre = tk.StringVar()
        self.var_descripcion = tk.StringVar()
        self.var_categoria = tk.StringVar()
        self.var_unidad = tk.StringVar(value="unidad")
        self.var_pcompra = tk.StringVar(value="0.00")
        self.var_pventa = tk.StringVar(value="0.00")
        self.var_stock = tk.StringVar(value="0")
        self.var_stockmin = tk.StringVar(value="0")
        self.var_estado = tk.StringVar(value="Activo")

        vcmd_codigo = (self.root.register(self.validate_codigo_keystroke), "%P")
        vcmd_decimal = (self.root.register(self.validate_decimal_keystroke), "%P")
        vcmd_int = (self.root.register(self.validate_int_keystroke), "%P")

        self.entry_codigo = ttk.Entry(form, textvariable=self.var_codigo, validate="key", validatecommand=vcmd_codigo)
        self.entry_nombre = ttk.Entry(form, textvariable=self.var_nombre)
        self.entry_descripcion = ttk.Entry(form, textvariable=self.var_descripcion)
        self.combo_categoria = ttk.Combobox(form, textvariable=self.var_categoria, state="readonly")
        self.entry_unidad = ttk.Entry(form, textvariable=self.var_unidad)
        self.entry_pcompra = ttk.Entry(form, textvariable=self.var_pcompra, validate="key", validatecommand=vcmd_decimal)
        self.entry_pventa = ttk.Entry(form, textvariable=self.var_pventa, validate="key", validatecommand=vcmd_decimal)
        self.entry_stock = ttk.Entry(form, textvariable=self.var_stock, validate="key", validatecommand=vcmd_int)
        self.entry_stockmin = ttk.Entry(form, textvariable=self.var_stockmin, validate="key", validatecommand=vcmd_int)
        self.combo_estado = ttk.Combobox(form, textvariable=self.var_estado, values=["Activo", "Inactivo"], state="readonly")

        self.entry_codigo.grid(row=0, column=1, sticky="ew", pady=4)
        self.entry_nombre.grid(row=1, column=1, sticky="ew", pady=4)
        self.entry_descripcion.grid(row=2, column=1, sticky="ew", pady=4)
        self.combo_categoria.grid(row=3, column=1, sticky="ew", pady=4)
        self.entry_unidad.grid(row=4, column=1, sticky="ew", pady=4)
        self.entry_pcompra.grid(row=5, column=1, sticky="ew", pady=4)
        self.entry_pventa.grid(row=6, column=1, sticky="ew", pady=4)
        self.entry_stock.grid(row=7, column=1, sticky="ew", pady=4)
        self.entry_stockmin.grid(row=8, column=1, sticky="ew", pady=4)
        self.combo_estado.grid(row=9, column=1, sticky="ew", pady=4)

        form.columnconfigure(1, weight=1)

        self.lbl_hint = ttk.Label(
            form,
            text="Código: 1 letra seguida de 3 números (ej.: P003). Precios con hasta 2 decimales. Stock solo números enteros.",
            foreground="#555555",
            wraplength=280,
        )
        self.lbl_hint.grid(row=10, column=0, columnspan=2, sticky="w", pady=(6, 4))

        buttons = ttk.Frame(form)
        buttons.grid(row=11, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        buttons.columnconfigure((0, 1, 2, 3), weight=1)

        ttk.Button(buttons, text="Nuevo", command=self.limpiar_formulario).grid(row=0, column=0, sticky="ew", padx=3)
        ttk.Button(buttons, text="Guardar", command=self.guardar_producto).grid(row=0, column=1, sticky="ew", padx=3)
        ttk.Button(buttons, text="Actualizar", command=self.actualizar_producto).grid(row=0, column=2, sticky="ew", padx=3)
        ttk.Button(buttons, text="Eliminar", command=self.eliminar_producto).grid(row=0, column=3, sticky="ew", padx=3)

    def validate_codigo_keystroke(self, proposed: str):
        if proposed == "":
            return True
        if len(proposed) > 4:
            return False
        if len(proposed) == 1:
            return proposed.isalpha()
        return proposed[:1].isalpha() and proposed[1:].isdigit()

    def validate_decimal_keystroke(self, proposed: str):
        if proposed == "":
            return True
        return bool(re.fullmatch(r"\d{0,8}(\.\d{0,2})?", proposed))

    def validate_int_keystroke(self, proposed: str):
        if proposed == "":
            return True
        return proposed.isdigit() and len(proposed) <= 9

    def cargar_categorias(self):
        self.categorias = ProductoService.listar_categorias()
        nombres = [cat["nombre"] for cat in self.categorias]
        self.combo_categoria["values"] = nombres
        if nombres:
            self.var_categoria.set(nombres[0])

    def get_categoria_id(self, nombre_categoria):
        for categoria in self.categorias:
            if categoria["nombre"] == nombre_categoria:
                return categoria["id_categoria"]
        return None

    def cargar_productos(self):
        self.poblar_tabla(ProductoService.listar_productos())

    def buscar(self):
        filtro = self.entry_buscar.get().strip()
        self.poblar_tabla(ProductoService.listar_productos(filtro))

    def poblar_tabla(self, productos):
        for item in self.tree.get_children():
            self.tree.delete(item)

        for p in productos:
            estado = "Activo" if p["estado"] == 1 else "Inactivo"
            self.tree.insert(
                "",
                "end",
                values=(
                    p["id_producto"], p["codigo"], p["nombre"], p.get("descripcion", ""), p["categoria"],
                    p["unidad_medida"], p["precio_compra"], p["precio_venta"],
                    p["stock_actual"], p["stock_minimo"], estado
                ),
            )

    def seleccionar_producto(self, event=None):
        selected = self.tree.selection()
        if not selected:
            return
        values = self.tree.item(selected[0], "values")
        self.selected_id = int(values[0])
        self.var_codigo.set(values[1])
        self.var_nombre.set(values[2])
        self.var_descripcion.set(values[3])
        self.var_categoria.set(values[4])
        self.var_unidad.set(values[5])
        self.var_pcompra.set(str(values[6]))
        self.var_pventa.set(str(values[7]))
        self.var_stock.set(str(values[8]))
        self.var_stockmin.set(str(values[9]))
        self.var_estado.set(values[10])

    def _raise_with_focus(self, message: str, widget):
        widget.focus_set()
        raise ValueError(message)

    def validar_formulario(self):
        codigo = self.var_codigo.get().strip().upper()
        self.var_codigo.set(codigo)
        nombre = self.var_nombre.get().strip()
        descripcion = self.var_descripcion.get().strip()
        unidad = self.var_unidad.get().strip() or "unidad"
        categoria = self.var_categoria.get().strip()

        if not codigo:
            self._raise_with_focus("Ingrese el código del producto.", self.entry_codigo)
        if not self.CODIGO_REGEX.fullmatch(codigo):
            self._raise_with_focus(
                "El código debe tener exactamente 4 caracteres: 1 letra seguida de 3 números, por ejemplo P003.",
                self.entry_codigo,
            )
        if ProductoService.existe_codigo(codigo, self.selected_id):
            self._raise_with_focus("Ya existe un producto con ese código.", self.entry_codigo)

        if not nombre:
            self._raise_with_focus("Ingrese el nombre del producto.", self.entry_nombre)
        if len(nombre) < 3:
            self._raise_with_focus("El nombre debe tener al menos 3 caracteres.", self.entry_nombre)
        if len(nombre) > 150:
            self._raise_with_focus("El nombre no puede superar los 150 caracteres.", self.entry_nombre)

        if len(descripcion) > 255:
            self._raise_with_focus("La descripción no puede superar los 255 caracteres.", self.entry_descripcion)

        if not categoria:
            self._raise_with_focus("Debe seleccionar una categoría.", self.combo_categoria)

        if len(unidad) > 30:
            self._raise_with_focus("La unidad de medida no puede superar los 30 caracteres.", self.entry_unidad)

        try:
            precio_compra = float(self.var_pcompra.get() or 0)
        except ValueError as exc:
            self._raise_with_focus("El precio de compra debe ser numérico.", self.entry_pcompra)
        try:
            precio_venta = float(self.var_pventa.get() or 0)
        except ValueError as exc:
            self._raise_with_focus("El precio de venta debe ser numérico.", self.entry_pventa)
        try:
            stock = int(self.var_stock.get() or 0)
        except ValueError as exc:
            self._raise_with_focus("El stock actual debe ser un número entero.", self.entry_stock)
        try:
            stock_min = int(self.var_stockmin.get() or 0)
        except ValueError as exc:
            self._raise_with_focus("El stock mínimo debe ser un número entero.", self.entry_stockmin)

        if precio_compra < 0:
            self._raise_with_focus("El precio de compra no puede ser negativo.", self.entry_pcompra)
        if precio_venta < 0:
            self._raise_with_focus("El precio de venta no puede ser negativo.", self.entry_pventa)
        if stock < 0:
            self._raise_with_focus("El stock actual no puede ser negativo.", self.entry_stock)
        if stock_min < 0:
            self._raise_with_focus("El stock mínimo no puede ser negativo.", self.entry_stockmin)
        if precio_venta < precio_compra:
            self._raise_with_focus(
                "El precio de venta no debería ser menor al precio de compra.",
                self.entry_pventa,
            )

        id_categoria = self.get_categoria_id(categoria)
        if id_categoria is None:
            self._raise_with_focus("La categoría seleccionada no es válida.", self.combo_categoria)

        return {
            "codigo": codigo,
            "nombre": nombre,
            "descripcion": descripcion,
            "id_categoria": id_categoria,
            "unidad_medida": unidad,
            "precio_compra": precio_compra,
            "precio_venta": precio_venta,
            "stock_actual": stock,
            "stock_minimo": stock_min,
            "estado": 1 if self.var_estado.get() == "Activo" else 0,
        }

    def guardar_producto(self):
        try:
            data = self.validar_formulario()
            ProductoService.registrar_producto(data)
            messagebox.showinfo("Éxito", "Producto registrado correctamente.")
            self.cargar_productos()
            self.limpiar_formulario()
        except Exception as exc:
            messagebox.showerror("Error de validación", str(exc))

    def actualizar_producto(self):
        if not self.selected_id:
            messagebox.showwarning("Aviso", "Seleccione un producto para actualizar.")
            return
        try:
            data = self.validar_formulario()
            ProductoService.actualizar_producto(self.selected_id, data)
            messagebox.showinfo("Éxito", "Producto actualizado correctamente.")
            self.cargar_productos()
            self.limpiar_formulario()
        except Exception as exc:
            messagebox.showerror("Error de validación", str(exc))

    def eliminar_producto(self):
        if not self.selected_id:
            messagebox.showwarning("Aviso", "Seleccione un producto para eliminar.")
            return
        if not messagebox.askyesno("Confirmar", "¿Seguro que desea eliminar el producto seleccionado?"):
            return
        try:
            ProductoService.eliminar_producto(self.selected_id)
            messagebox.showinfo("Éxito", "Producto eliminado correctamente.")
            self.cargar_productos()
            self.limpiar_formulario()
        except Exception as exc:
            messagebox.showerror("Error", str(exc))

    def limpiar_formulario(self):
        self.selected_id = None
        self.tree.selection_remove(self.tree.selection())
        self.var_codigo.set("")
        self.var_nombre.set("")
        self.var_descripcion.set("")
        self.var_unidad.set("unidad")
        self.var_pcompra.set("0.00")
        self.var_pventa.set("0.00")
        self.var_stock.set("0")
        self.var_stockmin.set("0")
        self.var_estado.set("Activo")
        if self.categorias:
            self.var_categoria.set(self.categorias[0]["nombre"])
        self.entry_codigo.focus_set()


if __name__ == "__main__":
    if not test_connection():
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "Error de conexión",
            "No se pudo conectar a MySQL. Revisa config.py, el usuario, la contraseña y que MySQL esté encendido.",
        )
        root.destroy()
    else:
        root = tk.Tk()
        LoginWindow(root)
        root.mainloop()
