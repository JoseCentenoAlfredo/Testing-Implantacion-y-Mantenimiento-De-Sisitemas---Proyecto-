Sistema local de inventario en Python + Tkinter + MySQL.

Cambios de esta versión:
- Validación de código: máximo 4 caracteres alfanuméricos.
- Validación de precios: solo números y hasta 2 decimales.
- Validación de stock: solo enteros.
- Mensajes de error específicos sin borrar el formulario.
- Detección de código duplicado.
- Carga correcta de la descripción al seleccionar un producto.

Pasos:
1. Ajusta config.py con tu usuario y clave de MySQL.
2. Ejecuta: pip install -r requirements.txt
3. Ejecuta: python main.py
